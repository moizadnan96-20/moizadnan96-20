import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cta-section',
  templateUrl: './cta-section.component.html',
  styleUrls: ['./cta-section.component.css']
})
export class CtaSectionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
