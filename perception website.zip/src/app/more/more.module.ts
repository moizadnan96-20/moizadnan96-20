import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MoreRoutingModule } from './more-routing.module';
import { MoreListComponent } from './more-list/more-list.component';


@NgModule({
  declarations: [MoreListComponent],
  imports: [
    CommonModule,
    MoreRoutingModule
  ]
})
export class MoreModule { }
