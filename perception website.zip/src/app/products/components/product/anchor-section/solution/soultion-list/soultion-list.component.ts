import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-soultion-list',
  templateUrl: './soultion-list.component.html',
  styleUrls: ['./soultion-list.component.css']
})
export class SoultionListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
