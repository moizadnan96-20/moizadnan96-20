import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-anchor-section',
  templateUrl: './anchor-section.component.html',
  styleUrls: ['./anchor-section.component.css'],
})
export class AnchorSectionComponent implements OnInit {



  constructor() {}

  ngOnInit(): void {}




}
