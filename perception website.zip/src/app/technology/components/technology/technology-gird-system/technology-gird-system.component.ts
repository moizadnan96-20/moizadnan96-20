import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-technology-gird-system',
  templateUrl: './technology-gird-system.component.html',
  styleUrls: ['./technology-gird-system.component.css']
})
export class TechnologyGirdSystemComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
