import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-jira-grid-section',
  templateUrl: './jira-grid-section.component.html',
  styleUrls: ['./jira-grid-section.component.css']
})
export class JiraGridSectionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
