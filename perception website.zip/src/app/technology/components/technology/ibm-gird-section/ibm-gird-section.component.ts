import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ibm-gird-section',
  templateUrl: './ibm-gird-section.component.html',
  styleUrls: ['./ibm-gird-section.component.css']
})
export class IbmGirdSectionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
