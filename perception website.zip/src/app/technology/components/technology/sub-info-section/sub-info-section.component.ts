import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sub-info-section',
  templateUrl: './sub-info-section.component.html',
  styleUrls: ['./sub-info-section.component.css']
})
export class SubInfoSectionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
