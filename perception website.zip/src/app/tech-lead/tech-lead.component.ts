import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tech-lead',
  templateUrl: './tech-lead.component.html',
  styleUrls: ['./tech-lead.component.css']
})
export class TechLeadComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
