import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-services',
  templateUrl: './manage-services.component.html',
  styleUrls: ['./manage-services.component.css']
})
export class ManageServicesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
